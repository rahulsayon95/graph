<h1>  Wellcome to facebook </h1>


 <a href="<?php   echo $this->facebook->login_url();  ?>">  Login with Facebook </a>